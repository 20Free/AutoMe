var http = require('http');
var Connection = require('tedious').Connection;
var Request = require('tedious').Request;

var server = http.createServer(function(request, response) {



    var config =
    {
        userName: 'autome@autome', // update me
        password: 'Localhackday2018', // update me
        server: 'autome.database.windows.net', // update me
        options:
        {
            database: 'AutoMeDB', //update me
            encrypt: true
        }
    }
    var connection = new Connection(config);

    // Attempt to connect and execute queries if connection goes through
    connection.on('connect', function(err)
        {
            if (err)
            {
                console.log(err)
            }
            else
            {
              response.writeHead(200, {"Content-Type": "text/plain"});
              response.end("successfully connected to DB!");
                //do queries
            }
        }
    );

});

var port = process.env.PORT || 1337;
server.listen(port);

console.log("Server running at http://localhost:%d", port);
// Create connection to database
